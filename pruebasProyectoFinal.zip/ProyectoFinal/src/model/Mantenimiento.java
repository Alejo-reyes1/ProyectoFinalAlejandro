package model;

import java.time.LocalDate;

public class Mantenimiento {
	private Vehiculo vehiculo;
	private String tipoMantenimiento;
	private final LocalDate fechaMantenimiento;
	private double costo;
	
	public Mantenimiento(Vehiculo vehiculo, LocalDate localDate, String tipoMantenimiento, double costo) {
		super();
		this.vehiculo = vehiculo;
		this.tipoMantenimiento = tipoMantenimiento;
		this.fechaMantenimiento =LocalDate.now();
		this.costo = costo;
	}

	public Mantenimiento(Vehiculo vehiculo2, Object localDate, String tipoMantenimiento2, double costo2) {
		this.fechaMantenimiento = null;
		// TODO Auto-generated constructor stub
	}

	public Vehiculo getVehiculo() {
		return vehiculo;
	}

	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}

	public String getTipoMantenimiento() {
		return tipoMantenimiento;
	}

	public void setTipoMantenimiento(String tipoMantenimiento) {
		this.tipoMantenimiento = tipoMantenimiento;
	}

	public double getCosto() {
		return costo;
	}

	public void setCosto(double costo) {
		this.costo = costo;
	}

	public LocalDate getFechaMantenimiento() {
		return fechaMantenimiento;
	}

	@Override
	public String toString() {
		return "Mantenimiento [vehiculo=" + vehiculo + ", tipoMantenimiento=" + tipoMantenimiento
				+ ", fechaMantenimiento=" + fechaMantenimiento + ", costo=" + costo + "]";
	}
	
}