package model;

import java.util.ArrayList;

public class Inventario {
	private static ArrayList<Vehiculo>vehiculos;

	public Inventario() {
		this.vehiculos = new ArrayList<>();
	}

	public static ArrayList<Vehiculo> getVehiculos() {
		try {
			return vehiculos;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vehiculos;
	}

	public void setVehiculos(ArrayList<Vehiculo> vehiculos) {
		this.vehiculos = vehiculos;
	}
	
	public void agregarVehiculo(Vehiculo vehiculo) {
		this.vehiculos.add(vehiculo);
	}
}
