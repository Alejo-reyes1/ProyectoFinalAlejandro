package model;

public interface MantenimientoVehiculo {
	public double calcularPrecioMantenimiento(double precioMantenimiento);

	}
