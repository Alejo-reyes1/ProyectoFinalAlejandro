package model;

public interface VentaVehiculo {
	
	public double calcularPrecioVenta(double precioVenta);

	double calcularPrecioMantenimiento(double precioMantenimiento);
	}

